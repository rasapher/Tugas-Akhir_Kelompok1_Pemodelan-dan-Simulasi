import random
from prettytable import PrettyTable
from queue import PriorityQueue

# Data probabilitas dan harga
probabilities = [
    {"range": (1, 5500), "probability": 0.22},
    {"range": (5501, 11001), "probability": 0.11},
    {"range": (11002, 16502), "probability": 0.33},
    {"range": (16503, 22003), "probability": 0.34},
]
harga_per_lembar = 150
investasi_bulanan = 84520000
hari_simulasi = 30
batas_waktu_tunggu = 30  # Batas waktu tunggu dalam menit

# Fungsi untuk menentukan jumlah kertas berdasarkan probabilitas
def generate_jumlah_kertas():
    rand = random.random()  # Bilangan acak 0-1
    cumulative = 0
    for item in probabilities:
        cumulative += item["probability"]
        if rand <= cumulative:
            return random.randint(*item["range"])

# Fungsi untuk menentukan jumlah pelanggan per hari (opsional, acak)
def generate_jumlah_pelanggan():
    return random.choices(
        population=[20, 30, 40],  # Jumlah pelanggan harian
        weights=[0.2, 0.5, 0.3],  # Probabilitas pelanggan
        k=1
    )[0]

# Fungsi simulasi berbasis event
def simulasi_event():
    total_pendapatan = 0
    waktu_total = 0
    pelanggan_terlayani = 0
    pelanggan_tidak_terlayani = 0
    kapasitas_karyawan = 2  # Jumlah karyawan/machine
    tabel_harian = PrettyTable(["Hari", "Pelanggan", "Pendapatan Harian", "Rata-rata Waktu Tunggu (menit)", "Tidak Dilayani"])

    for hari in range(1, hari_simulasi + 1):
        pendapatan_harian = 0
        waktu_harian = 0
        waktu_layanan = PriorityQueue()  # Antrean waktu layanan untuk karyawan
        pelanggan_harian = 0  # Pelanggan yang tidak dilayani hari ini

        pelanggan_per_hari = generate_jumlah_pelanggan()  # Jumlah pelanggan per hari (acak)

        for pelanggan in range(pelanggan_per_hari):
            jumlah_kertas = generate_jumlah_kertas()
            pendapatan = jumlah_kertas * harga_per_lembar
            waktu_layanan_pelanggan = jumlah_kertas / 100  # Waktu layanan pelanggan (1 menit per 100 lembar)

            # Cek jika karyawan tersedia
            if waktu_layanan.qsize() < kapasitas_karyawan:
                waktu_layanan.put(waktu_layanan_pelanggan)
                waktu_harian += waktu_layanan_pelanggan
                pendapatan_harian += pendapatan
                pelanggan_terlayani += 1
            else:
                # Ambil waktu layanan selesai tercepat dari antrean
                waktu_tersedia = waktu_layanan.get()
                waktu_tunggu = waktu_tersedia + waktu_layanan_pelanggan
                if waktu_tunggu <= batas_waktu_tunggu:
                    waktu_harian += waktu_tunggu
                    waktu_layanan.put(waktu_tunggu)
                    pendapatan_harian += pendapatan
                    pelanggan_terlayani += 1
                else:
                    pelanggan_harian += 1  # Pelanggan tidak dilayani

        pelanggan_tidak_terlayani += pelanggan_harian
        waktu_total += waktu_harian
        rata_rata_waktu = waktu_harian / max(pelanggan_per_hari - pelanggan_harian, 1)
        tabel_harian.add_row([hari, pelanggan_per_hari, pendapatan_harian, round(rata_rata_waktu, 2), pelanggan_harian])

        total_pendapatan += pendapatan_harian

    rata_rata_waktu_tunggu = waktu_total / max(pelanggan_terlayani, 1)
    status = "Untung" if total_pendapatan > investasi_bulanan else "Rugi"

    print(tabel_harian)
    print(f"Total Pendapatan Bulanan: Rp{total_pendapatan:,}")
    print(f"Rata-rata Waktu Tunggu: {rata_rata_waktu_tunggu:.2f} menit")
    print(f"Pelanggan Tidak Dilayani: {pelanggan_tidak_terlayani}")
    print(f"Investasi Bulanan: Rp{investasi_bulanan:,}")
    print(f"Status: {status}")

if __name__ == "__main__":
    print("SIMULASI DISKRIT BERBASIS EVENT: JASA FOTOCOPY")
    simulasi_event()
