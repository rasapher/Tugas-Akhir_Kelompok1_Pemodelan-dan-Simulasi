import os
import numpy
from prettytable import PrettyTable

def set_title():
    print("SIMULASI JASA FOTOCOPY")

def simulasi():
    # Biaya tetap
    a = 2420000 * 30  # kertas
    b = 284000 * 30   # tinta
    gaji_karyawan = 3400000
    c = a + b + gaji_karyawan

    awal = 1
    batas = 31

    # Data range probabilitas dan jumlah kertas
    range_kertas = [
        list(range(0, 21)),
        list(range(22, 32)),
        list(range(33, 65)),
        list(range(66, 99))
    ]
    jml_kertas = [
        list(range(1, 5501)),
        list(range(5501, 11002)),
        list(range(11003, 16503)),
        list(range(16504, 22004))
    ]

    list_pendapatan = []

    # Simulasi per hari
    for i in range(awal, batas):
        bilrand1 = numpy.random.randint(0, 100)
        for x in range(len(range_kertas)):  # Loop berdasarkan panjang `range_kertas`
            if bilrand1 in range_kertas[x]:
                var_rand_kertas = numpy.random.choice(jml_kertas[x])
                pendapatan_harian = var_rand_kertas * 150
                table_output(i, var_rand_kertas, pendapatan_harian, c)
                list_pendapatan.append(pendapatan_harian)
                break  # Keluar dari loop setelah ditemukan range yang cocok

    # Perhitungan pendapatan
    total_pendapatan = sum(list_pendapatan)
    rata_rata_keuntungan = total_pendapatan / 30
    print(f"Pendapatan 1 Bulan: {total_pendapatan}")
    print(f"Investasi: {c}")
    print(f"Rata-rata keuntungan: {rata_rata_keuntungan}")

    # Membuat folder hasil jika belum ada
    os.makedirs('./hasil', exist_ok=True)

    # Menulis hasil ke file
    with open('./hasil/file_simulasi40.txt', 'w') as w:
        w.writelines(f"Pendapatan: {total_pendapatan}\n")
        w.writelines(f"Investasi: {c}\n")
        w.writelines(f"Rata-rata Keuntungan: {rata_rata_keuntungan}\n")
        if total_pendapatan > c:
            print("Status: Untung")
            w.writelines("Status: Untung\n")
        else:
            print("Status: Rugi")
            w.writelines("Status: Rugi\n")

def table_output(var1, var2, var3, var4):
    t = PrettyTable(['Hari', 'Jumlah Kertas', 'Pendapatan', 'Investasi'])
    t.add_row([var1, var2, var3, var4])
    print(t)

if __name__ == '__main__':
    set_title()
    simulasi()
