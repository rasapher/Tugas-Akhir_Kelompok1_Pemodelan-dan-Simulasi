# SimulasiPercepatanBalikModal
Projek Akhir Semester Pemodelan dan Simulasi

# Output Pada Terminal
![Simulasi1](https://user-images.githubusercontent.com/60762912/104555436-d6847000-5678-11eb-92fe-d4d5eafe381d.PNG)

# Output Pada File txt
![Simulasi2](https://user-images.githubusercontent.com/60762912/104555516-fddb3d00-5678-11eb-9e4b-ea49dce019bc.PNG)

# Penjelasan Lengkap Silahkan Kunjungi Youtube kami
https://www.youtube.com/watch?v=PRZ1Ux1x3FU
![Simulasi3](https://user-images.githubusercontent.com/60762912/104556026-c9b44c00-5679-11eb-8415-183f56823093.PNG)
